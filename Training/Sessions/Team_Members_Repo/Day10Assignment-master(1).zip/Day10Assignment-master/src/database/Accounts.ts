export const accounts = [
    {
      account: '123456010220001',
      name: 'Leanne Graham',
      bal: 1000.00
    },
    {
      account: '123456010220002',
      name: 'Ervin Howell',
      bal: 25000.00
    },
    {
      account: '123456010220003',
      name: 'Jenny Saul',
      bal: 5000.00
    },
    {
      account: '123456010220004',
      name: 'Rupert Craig',
      bal: 9000.00
    },
    {
      account: '123456010220005',
      name: 'Jimmy Doe',
      bal: 200.00
    },
    {
      account: '123456010220006',
      name: 'Devaughn Myvette',
      bal: 6500000.00
    }
];