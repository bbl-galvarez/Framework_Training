let array = [1, "string", false];

for (let astr of array) {
    console.log(astr);
}

let list = [4, 5, 6];

for (let i in list) {
    console.log(i)
};

for (let i of list) {
    console.log(i)
};