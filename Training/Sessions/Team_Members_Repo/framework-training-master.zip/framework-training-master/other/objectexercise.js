var myCats = [
    {name : "Lizzie", age: 18},
    {name: "Tom", age: 15}
];

for (var i = 0; i < myCats.length; i++) {
    var myCat = myCats[i];
    console.log(myCat.name + " is " + myCat.age + " years old");
}
