var age = 13;

if (age > 16) {
    console.log("Yes. You can drive!");
} else {
    console.log("Sorry. But you have " + (16 - age) + " years before you can drive.");
}