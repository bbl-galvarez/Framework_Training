var array = [1, "string", false];
for (var _i = 0, array_1 = array; _i < array_1.length; _i++) {
    var astr = array_1[_i];
    console.log(astr);
}
var list = [4, 5, 6];
for (var i in list) {
    console.log(i);
}
;
for (var _a = 0, list_1 = list; _a < list_1.length; _a++) {
    var i = list_1[_a];
    console.log(i);
}
;
