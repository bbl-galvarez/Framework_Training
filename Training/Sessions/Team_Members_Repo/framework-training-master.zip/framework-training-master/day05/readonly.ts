interface Point {
    readonly x: number;
    readonly y: number;
}

let pl: Point = {x: 10, y: 20};
console.log(pl.x);

//pl.x = 5;