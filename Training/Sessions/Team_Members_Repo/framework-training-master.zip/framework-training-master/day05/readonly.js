var pl = { x: 10, y: 20 };
console.log(pl.x);
//pl.x = 5;
