drEvil(1000000);

function drEvil(number) {

    filler = "";
    if (number === 1000000) {
        filler = "(pinky)"
    } 
    console.log("Dr Evil (" + number + "): " + number + " dollars " + filler);

}