export function Greeter(name: string) {
    return "Hello there " + name + "!";
}