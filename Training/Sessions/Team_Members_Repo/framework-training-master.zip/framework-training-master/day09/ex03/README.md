# Welcome to the TS/Introduction Day09 Excercise 03

**Excercise03**

Contains the demo code on how to include an external framework library called
**got**. It needed the typings aside from the got library installation, see the package.json and
**got** is used to call web services, supporting Asynchronous operations.


**NOTE: On line 18 we called an external service**
got.get('here goes your end point'  , replace with a URL http:// or https:// of
your end point.

**To run the excercise run the following commands from this directory**

```
npm install
npm start

```
