let lizard = new Zoo.Reptile();
let penguin = new Zoo.Bird();

console.log(lizard.skinType);
console.log(lizard.isMammal());

console.log("\n");

console.log(penguin.skinType);
console.log(penguin.isMammal());