namespace Zoo {
    
    export class Bird implements ZooAnimal {
        skinType = "feather";
        isMammal() {
            return true;
        }
    }

}