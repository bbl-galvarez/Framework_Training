namespace Zoo {
    export interface ZooAnimal {
        skinType: string,
        isMammal(): boolean,
    }
}