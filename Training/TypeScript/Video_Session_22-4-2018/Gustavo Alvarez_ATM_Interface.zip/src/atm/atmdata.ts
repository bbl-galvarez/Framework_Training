export var InitialData = [
    {accountNumber: '12345-1', currentBalance: 500},
    {accountNumber: '12222-1', currentBalance: 1500},
    {accountNumber: '13333-1', currentBalance: 300}
]