//Gustavo Alvarez Dr. Evil assignment

function  DrEvil(amt){

    var message;

    if (amt === 1000000){
        message = amount + " dollars (pinky)";
    }else{
        message = amount + " dollars";
    }

    return message;

}

console.log(DrEvil(10));
console.log(DrEvil(1000000));